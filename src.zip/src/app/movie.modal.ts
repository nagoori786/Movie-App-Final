export class Movie{
    imdbId:number
    movieTitle:string
    comment:string
    rating:string
    yearOfRelease:string

    public Movie(){}

}